using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ConditionDB
{
    public static Dictionary<ConditionID, Condition> Conditions { get; set; } = new Dictionary<ConditionID, Condition>()
    {
        {
            ConditionID.psn,
            new Condition()
            {
                Name = "중독",
                StartMessage = "(은)는 중독되었다!",
                OnAfterTurn = (Unit unit) => 
                {
                    unit.UpdateHP(unit.MaxHP / 8);
                    unit.StatusChanges.Enqueue($"{unit.Base.Name}(은)는 중독 데미지를 입고있다!");
                }
            }
        },
        {
            ConditionID.brn,
            new Condition()
            {
                Name = "화상",
                StartMessage = "(은)는 화상을 입었다!",
                OnAfterTurn = (Unit unit) => 
                {
                    unit.UpdateHP(unit.MaxHP / 16);
                    unit.StatusChanges.Enqueue($"{unit.Base.Name}(은)는 화상 데미지를 입고있다!");
                }
            }
        },
        {
            ConditionID.par,
            new Condition()
            {
                Name = "마비",
                StartMessage = "(은)는 마비에 걸렸다!",
                OnBeforeMove = (Unit unit) => 
                {
                    if (Random.Range(1, 5) == 1)
                    {
                        unit.StatusChanges.Enqueue($"{unit.Base.Name}(은)는 몸이 움직이지 않는다!");
                        return false;
                    }
                    return true;
                }
            }
        },
        {
            ConditionID.frz,
            new Condition()
            {
                Name = "냉동",
                StartMessage = "(은)는 얼어붙었다!",
                OnBeforeMove = (Unit unit) => 
                {
                    if (Random.Range(1, 5) == 1)
                    {
                        unit.StatusChanges.Enqueue($"{unit.Base.Name}(은)는 녹았다!");
                        unit.CureStatus();
                        return true;
                    }
                    unit.StatusChanges.Enqueue($"{unit.Base.Name}(은)는 얼어서 움직이지 못한다!");
                    return false;
                }
            }
        },
        {
            ConditionID.slp,
            new Condition()
            {
                Name = "수면",
                StartMessage = "(은)는 골아떨어졌다!",
                OnStart = (Unit unit) =>
                {
                    unit.StatusTime = 0;
                },
                OnBeforeMove = (Unit unit) => 
                {
                    
                    
                    
                    int awakeValue = Random.Range(-1 + Mathf.FloorToInt(unit.StatusTime / 2f),
                                                    1 + Mathf.RoundToInt(unit.StatusTime / 2f)); // 1개 늘리고 최대를 1개 뺴고 두개를 번갈아가면서 하네
                    // unit.StatusTime = 0, -1 이상 1 미만, -1, 0, 1이상 확률 0%
                    // unit.StatusTime = 1, -1 이상 2 미만, -1, 0, 1, 1이상 확률 33%
                    // unit.StatusTime = 2, 0 이상 2 미만, 0, 1, 1이상 확률 50%
                    // unit.StatusTime = 3, 0 이상 3 미만, 0, 1, 2, 1이상 확률 66%
                    // unit.StatusTime = 4, 1 이상 3 미만, 1, 2, 1이상 확률 100%
                    unit.StatusTime++;
                    if (awakeValue >= 1)
                    {
                        unit.StatusChanges.Enqueue($"{unit.Base.Name}(은)는 눈을 떴다!");
                        unit.CureStatus();
                        return true;
                    }
                    unit.StatusChanges.Enqueue($"{unit.Base.Name}(은)는 잠잔다!");
                    return false;
                }
            }
        },
    };
}

public enum ConditionID
{
    /* 
        psn = 중독
        brn = 화상
        slp = 수면
        par = 마비
        frz = 냉동
        dpsn = 맹독 <= 구현 할 수 있을지 모르겠음
    */
    none, psn, brn, slp, par, frz, dpsn
}