using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class PlayerHud : BattleHud
{
    [SerializeField] TextMeshProUGUI HPText;
    [SerializeField] TextMeshProUGUI MaxHPText;
    protected Unit unit;
    
    public override void SetData(Unit unit)
    {
        this.unit = unit;
        HPText.text = $"{unit.HP}";
        MaxHPText.text = $"/{unit.MaxHP}";
        base.SetData(unit);
    }

    public override IEnumerator UpdateHP()
    {
        HPText.text = $"{unit.HP}";
        MaxHPText.text = $"/{unit.MaxHP}";
        yield return base.UpdateHP();
    }
}
