using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class BattleHud : MonoBehaviour
{
    [SerializeField] TextMeshProUGUI nameText;
    [SerializeField] TextMeshProUGUI LevelText;
    [SerializeField] HPBar hpBar;
    // [SerializeField] Status status;

    Unit _unit;

    public TextMeshProUGUI NameText {
        get { return nameText; }
    }

    public virtual void SetData(Unit unit)
    {
        _unit = unit;

        nameText.text = unit.Base.Name;
        LevelText.text = "Lvl " + unit.Level;
        hpBar.SetHP((float) unit.HP / unit.MaxHP);
    }

    public virtual IEnumerator UpdateHP()
    {
        if (_unit.HPChanged)
        {
            yield return hpBar.SetHPSmooth((float) _unit.HP / _unit.MaxHP);
        }
    }

    // public virtual IEnumerator UpdateStatus()
    // {
    //     yield return 
    //     switch(typeText){
    //         case "없음":
    //             GetComponent<Image>().sprite = type.Base.Normal;
    //             break;
    //         case "불꽃":
    //             GetComponent<Image>().sprite = type.Base.Fire;
    //             break;
    //         case "풀":
    //             GetComponent<Image>().sprite = type.Base.Grass;
    //             break;
    //         case "물":
    //             GetComponent<Image>().sprite = type.Base.Water;
    //             break;
    //         case "번개":
    // }
}
